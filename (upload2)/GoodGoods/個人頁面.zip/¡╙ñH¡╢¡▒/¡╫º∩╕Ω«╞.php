<?php 

include 'connection.php';
session_start();

  if(isset($_SESSION['luseraccount']))
  {     
     // $user = $_SESSION['luseraccount'];
   
  }else{
    header("location:new登入註冊.php");
  }
?>

<?php
if ($stmt = $con->prepare('UPDATE userinfo set Username= ? , Email= ?, Birthday= ?, Gender= ?, Phonenumber=? where Useraccount = "'.$_SESSION['luseraccount'].'"') ) {
				
				$stmt->bind_param('sssss', $_POST['alt-name'], $_POST['alt-mail'], $_POST['alt-bd'], $_POST['alt-gender'], $_POST['alt-num']);
				$stmt->execute();
				echo "修改成功！";
			} else{
	// Something is wrong with the sql statement, check to make sure accounts table exists with all 3 fields.
			echo 'Could not prepare statement!!';
		}
	
	
?>
