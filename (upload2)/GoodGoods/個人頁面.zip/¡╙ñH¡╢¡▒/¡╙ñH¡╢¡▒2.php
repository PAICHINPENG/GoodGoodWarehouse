<?php
include 'connection.php';
session_start();

  if(isset($_SESSION['luseraccount']))
  {     
     // $user = $_SESSION['luseraccount'];
   
  }else{
    header("location:new登入註冊.php");
  }
?>

<?php

$host = "localhost";
$user = "root";
$password = "";
$db = "goodgoods好好藏-1";

$con = mysqli_connect($host,$user,$password);
if (empty($con)) {
  print mysqli_error($con);
    die("Connection failed: " );
    exit;
}
if(!mysqli_select_db($con,$db)){
  die("無法選擇資料庫");
}
mysqli_query($con, "SET NAMES 'utf8'");

$sql="select * from userinfo where Useraccount = '".$_SESSION['luseraccount']."'";
$result = mysqli_query($con, $sql);

if(!$result){
  echo ("錯誤". mysqli_error($con));
  exit();
}


if(!empty($result)){
while($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
  $name= $row['Username'];
  $email= $row['Email'];
  $bd= $row['Birthday'];
  $acc= $row['Useraccount'];
  $num= $row['Phonenumber'];
  $gen= $row['Gender'];
  }
}
else{echo "wrong";}
?>

<!DOCTYPE html>
<head>
<meta charset="utf-8" />
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width;initial-scale=10.0">
<link rel="stylesheet"  href="newhome.css ">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>
html,body{
    height: 100%;
  /* background-color: azure; */
    font-family: "Lato", sans-serif;

  }
  .header{
    height: 140px;
    position: relative;
    top:0;
    z-index: 900;
    background-color:#5995fd;
    color:  #FFFFFF;
  }
 .main-content{
    min-height: 100%;
    padding-top: 10px;
    padding-bottom:50px;  /*same height as footer-height*/  
  }
  .footer{
     position: fixed;
     bottom:0px;

     margin-top: -50px; /* negative value of footer height */
     height: 150px;  
     clear:both
   }

/*header text*/
.headertext{
  color: white;
  width: 100%;
  font-size: 55px; /*字體大小*/
  line-height:135PX; /*字置中*/
  position: absolute;
  left: 10px;
}

/*右側導航欄*/
.sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  right: 0;
  background-color: white;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 35px;  /*字體大小*/
  color: #818181;
  display: block;
  transition: 0.3s;
 
}

.sidenav a:hover {
  color: white;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

div.absolute{
 position: absolute;
 top: 0px;
 right: 1%;
 line-height:120PX;  /*右側導航欄按鈕位置*/
}


@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}




*{
	margin: 0;
	padding: 0;
	box-sizing: border-box;
	font-family: 'Montserrat',sans-serif;
}
.wrapper{
	max-width: 80%;
	width: 100%;
	height: 80%;
	background:  #fff;
	margin: 20px auto;
	padding:30px;
	box-shadow: 1px 1px 2px rgba(0,0,0,0.125)
}
.wrapper .form{
	width: 100%;
}
.wrapper .form .input_field{
	margin-bottom: 15px;
	display: flex;
	align-items: center;
}
.wrapper .form .input_field label{
	width: 200px;
	color: #2f3640;
	margin-right: 10px;
	font-size: 20px;
}
.wrapper .form .input_field .input{
	width: 100%;
	outline: none;
	border: 1px solid #d5dbd9;
	font-size: 20px;
	padding: 8px 10px;
	border-radius: 3px;
	transition: all 0.3s ease;
}
.wrapper .form .input_field .custom_select{
	position: relative;
	width: 100%;
	height: 37px;
}
.wrapper .form .input_field .custom_select select{
	-webkit-appearance: none;
	appearance:none;
	border: 1px solid #d5dbd9;
	width:100%;
	height: 100%;
	padding: 8px 10px;
	border-radius: 3px;
	outline: none;
	font-size: 15px;
}
.wrapper .form .input_field .custom_select:before{
	content: "";
	position: absolute;
	top:12px;
	right: 10px;
	border:8px solid;
	border-color:#d5dbd9 transparent transparent;
}
.wrapper .form .input_field .input:focus,
.wrapper .form .input_field select:focus{
	border:1px solid #273c75;
}
.wrapper .form .input_field .btn{
	width: 40%;
	padding: 8px 10px;
	font-size: 20px;
	border:0;
	background: #0097e6;
	color: #fff;
	cursor: pointer;
	border-radius: 3px;
	outline: none;

}
.wrapper .form .input_field:last-child{
	margin-bottom: 0;
}
.wrapper .form .input_field .btn:hover{
	background: #40739e;
}
@media(max-width: 420px){
	.wrapper .form .input_field{
		flex-direction: column;
		align-items: flex-start;
	}
	.wrapper .form .input_field label{
		margin-bottom: 5px;
	}
}

/*下方按鈕 icon bar*/
.icon-bar {
  width: 100%;
  background-color: #ffaaa7;  /*下方導航欄顏色*/
  overflow: auto;
  height: 150px;
}
.icon-bar a {
  float: left;
  width: 25%;
  text-align: center;
  padding: 12px 0;
  transition: all 0.3s ease;
  color: white;
  font-size: 36px;
}
.icon-bar a:hover {
  background-color: white;
}

.active {
  background-color: #04AA6D;
}
</style>
</head>
<html>
  <body>
    <header class='header'>
      <div class="headertext">Goodgoods好好藏</div>

      <div id="mySidenav" class="sidenav">   
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>   
        <a href="new客服頁面.html">客服中心</a>
        <a href="logout.php">登出</a>
      </div>
      <div class=absolute>
        <span style="font-size:130px /*更改右側導航欄大小*/;cursor:pointer;" onclick="openNav()">&#9776;</span>
      </div>
    </header>

<content class="main-content">
    <div class="wrapper">
    	<button type="submit" value="" style="width:250px;height:250px;border-radius: 999em; display:block; margin:auto;">
    		<img style="border-radius: 999em; width: 250px;" src="goodgoods4.png" alt="圓形圖">
    		<p style="font-size: 20px; line-height: 10px;">更改照片</p>
 		</button>
 		<br>
 		<br>
 		<br>
 		<button type="button" name="alt-pw" style="width: 100px; height: 30px;" id="alt-pw" >
 			<p style="font-size: 20px">修改密碼</p>  
 		</button>
 		<br>
 		<br>
    	<div class="form" >
        <form action="修改資料.php" method="post" >
        <div class="input_field">
          <label>使用者帳號</label>
          <input disabled type="text" class="input" value= "<?php echo $acc; ?>" >
          
        </div>
        <br>
        <br>
    		<div class="input_field">
    			<label>使用者名稱</label>
    			<input type="text" class="input" value= "<?php echo $name; ?>" name="alt-name" >
          
    		</div>
    		<br>
    		<br>
    		
    		<div class="input_field">
    			<label>性別</label>
    			<div class="custom_select" >	
	    			<select name="alt-gender" >
	    				<option value="male" >請選擇性別</option>
				    	<option value="male" >男</option>
				        <option value="female">女</option>
				        <option value="其他">其他</option>       				
	      			</select>
      			</div>
    		</div>
    		<br>
    		<br>
    		
    		<div class="input_field">
    			<label>生日</label>
    			<input type="date" class="input" style="position: absolute;left: 292px;" value="<?php echo $bd; ?>" name="alt-bd">
    		</div>
    		<br>
    		<br>
    		
    		<div class="input_field">
    			<label>手機號碼</label>
    			<input type="text" class="input" value="<?php echo $num; ?>" name="alt-num">
    		</div>
    		<br>
    		<br>
    		
    		<div class="input_field">
    			<label>Email</label>
    			<input type="email" class="input" value="<?php echo $email; ?>" name="alt-mail">
    		</div>
    		<br>
    		<br>
    	
    		<div class="input_field">
    			<input type="submit" value="儲存" class="btn">
    		</div>
        </form>
    	</div>
    </div>
</content>


  <footer class="footer">
    <div class="icon-bar">
      <a href="#"><img src="goodgoods1.png" style="width:60%"></a> 
      <a href="#"><img src="goodgoods2.png" style="width:45%"></a> 
      <a href="#"><img src="goodgoods3.png" style="width:60%"></a> 
      <a href="#"><img src="goodgoods4.png" style="width:60%"></a>
    </div>
  </footer>

 
	<script>
	function openNav() {
	  document.getElementById("mySidenav").style.width = "200px";   /*右側導航欄*/
	}

	function closeNav() {
	  document.getElementById("mySidenav").style.width = "0";
	}
	</script>
  </body>
</html> 
	